library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity tb_top_alu is
    -- Testbench entities do not have external ports
end tb_top_alu;

architecture Behavioral of tb_top_alu is
    -- 50 MHz clock period (20 ns) to ensure timing closure without setup time violations[cite: 1, 8]
    constant CLK_PERIOD : time := 20 ns;

    -- Unit Under Test (UUT) interface signals
    signal clk       : std_logic := '0';                                      -- Simulated clock source
    signal rst       : std_logic := '0';                                      -- Active-high synchronous reset
    signal opcode    : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0'); -- 4-bit operation select bus
    signal src_A     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0'); -- 32-bit operand A input bus
    signal src_B     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0'); -- 32-bit operand B input bus
    signal alu_out   : std_logic_vector(DATA_WIDTH-1 downto 0);               -- 32-bit data result from ALU
    signal alu_flags : std_logic_vector(7 downto 0);                          -- 8-bit status flags from ALU

begin

    -- Instantiate the baseline standard (un-gated) ALU as the Unit Under Test (UUT)
    UUT: entity work.top_alu
        port map (
            clk       => clk,
            rst       => rst,
            opcode    => opcode,
            src_A     => src_A,
            src_B     => src_B,
            alu_out   => alu_out,
            alu_flags => alu_flags
        );

    -- Clock Generation Process: Produces a continuous 50 MHz clock with a 50% duty cycle
    clk_process: process
    begin
        clk <= '0';
        wait for CLK_PERIOD / 2; -- Low phase (10 ns)
        clk <= '1';
        wait for CLK_PERIOD / 2; -- High phase (10 ns)
    end process;

    -- High-Stress Stimulus Process: Drives operations to maximize dynamic switching activity[cite: 4]
    stim_proc: process
        -- Alternating bit vectors (0101... and 1010...) used to maximize toggle rate on data lines[cite: 4, 5]
        variable var_A : std_logic_vector(DATA_WIDTH-1 downto 0) := x"55555555";
        variable var_B : std_logic_vector(DATA_WIDTH-1 downto 0) := x"AAAAAAAA";
    begin		
        -- Apply initial synchronous reset to clear internal pipeline registers
        rst <= '1';
        wait for CLK_PERIOD * 2; -- Hold reset for 2 clock cycles
        rst <= '0';
        wait for CLK_PERIOD;     -- Wait 1 clock cycle for system stabilization

        -- Outer loop: Repeat the entire instruction workload 10 times[cite: 4]
        for loop_count in 1 to 10 loop
            -- Inner loop: Sequentially sweep through all 16 arithmetic, logic, shift, and set opcodes[cite: 4]
            for op_val in 0 to 15 loop
                -- Force bitwise inversion on every instruction to flip all 32 bits on both buses simultaneously[cite: 4, 5]
                var_A := not var_A;
                var_B := not var_B;
                
                -- Drive new opcode and inverted operand vectors to the ALU input ports
                opcode <= std_logic_vector(to_unsigned(op_val, OP_WIDTH));
                src_A  <= var_A;
                src_B  <= var_B;

                -- Wait 2 clock periods for data to propagate through both the input and output pipeline registers
                wait for CLK_PERIOD * 2;
            end loop;
        end loop;

        -- Test termination sequence: Assert reset and suspend process execution indefinitely
        rst <= '1';
        wait for CLK_PERIOD * 2;
        wait; -- Suspend simulation
    end process;

end Behavioral;