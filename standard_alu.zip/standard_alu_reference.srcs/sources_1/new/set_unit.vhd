library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity set_unit is
    Port (
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Operation select control input
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Primary input operand A
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Secondary input operand B
        set_out : out std_logic_vector(DATA_WIDTH-1 downto 0)   -- 32-bit boolean flag output
    );
end set_unit;

architecture Behavioral of set_unit is
begin
    process(op_sel, in_A, in_B)
        variable v_out : std_logic_vector(DATA_WIDTH-1 downto 0); -- Variable to build the comparison output vector
    begin
        v_out := (others => '0'); -- Default all bits of the output vector to zeros

        -- Multiplexer structure to evaluate comparison conditions based on the opcode
        case op_sel is
            when OP_SLT  => 
                -- Set if A < B treating inputs as signed numbers
                if signed(in_A) < signed(in_B) then v_out(0) := '1'; end if;
            when OP_SLTU => 
                -- Set if A < B treating inputs as unsigned numbers
                if unsigned(in_A) < unsigned(in_B) then v_out(0) := '1'; end if;
            when OP_SEQ  => 
                -- Set if A equals B
                if in_A = in_B then v_out(0) := '1'; end if;
            when OP_SNE  => 
                -- Set if A is not equal to B
                if in_A /= in_B then v_out(0) := '1'; end if;
            when others  => 
                null; -- Keep v_out as all zeros for non-set opcodes
        end case;

        set_out <= v_out; -- Drive the final calculated vector to the entity output port
    end process;
end Behavioral;