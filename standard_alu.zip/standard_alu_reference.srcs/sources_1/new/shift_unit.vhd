library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity shift_unit is
    Port (
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Operation select control input
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Primary input operand A (data to be shifted)
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Secondary input operand B (lower bits determine shift amount)
        shift_out : out std_logic_vector(DATA_WIDTH-1 downto 0)   -- Computed shift/rotate result output
    );
end shift_unit;

architecture Behavioral of shift_unit is
begin
    process(op_sel, in_A, in_B)
        variable shamt : integer range 0 to 31;   -- Variable to store the integer shift amount (0 to 31)
        variable v_sll, v_srl, v_sra, v_ror : std_logic_vector(DATA_WIDTH-1 downto 0); -- Variables for shift results
    begin
        -- Extract the shift amount from the lower 5 bits of operand B (2^5 = 32 possible shift values)
        shamt := to_integer(unsigned(in_B(4 downto 0)));
        
        -- All shift and rotate variants compute simultaneously in parallel regardless of opcode selection
        v_sll := std_logic_vector(shift_left(unsigned(in_A), shamt));   -- Shift Left Logical
        v_srl := std_logic_vector(shift_right(unsigned(in_A), shamt));  -- Shift Right Logical
        v_sra := std_logic_vector(shift_right(signed(in_A), shamt));    -- Shift Right Arithmetic (preserves sign bit)
        v_ror := std_logic_vector(rotate_right(unsigned(in_A), shamt)); -- Rotate Right

        -- Multiplexer structure to select the final output based on the opcode
        case op_sel is
            when OP_SLL  => shift_out <= v_sll; -- Select shift left logical result
            when OP_SRL  => shift_out <= v_srl; -- Select shift right logical result
            when OP_SRA  => shift_out <= v_sra; -- Select shift right arithmetic result
            when OP_ROR  => shift_out <= v_ror; -- Select rotate right result
            when others  => shift_out <= (others => '0'); -- Default case: clear output to zeros for invalid shift opcodes
        end case;
    end process;
end Behavioral;