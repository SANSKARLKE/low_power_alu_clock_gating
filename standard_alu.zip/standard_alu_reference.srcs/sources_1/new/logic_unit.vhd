library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.alu_pkg.ALL;

entity logic_unit is
    Port (
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Operation select control input
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Primary input operand A
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Secondary input operand B (used for two-operand logic functions)
        log_out : out std_logic_vector(DATA_WIDTH-1 downto 0)   -- Computed bitwise logic result output
    );
end logic_unit;

architecture Behavioral of logic_unit is
begin
    process(op_sel, in_A, in_B)
        variable v_and, v_or, v_xor, v_not : std_logic_vector(DATA_WIDTH-1 downto 0); -- Variables to hold intermediate bitwise results
    begin
        -- All logic operations calculate simultaneously in parallel regardless of the opcode selection
        v_and := in_A and in_B;  -- Compute bitwise AND across all 32 bits
        v_or  := in_A or in_B;   -- Compute bitwise OR across all 32 bits
        v_xor := in_A xor in_B;  -- Compute bitwise XOR across all 32 bits
        v_not := not in_A;       -- Compute bitwise NOT inversion on operand A

        -- Multiplexer structure to select the final output based on the opcode
        case op_sel is
            when OP_AND  => log_out <= v_and;  -- Select bitwise AND result
            when OP_OR   => log_out <= v_or;   -- Select bitwise OR result
            when OP_XOR  => log_out <= v_xor;  -- Select bitwise XOR result
            when OP_NOT  => log_out <= v_not;  -- Select bitwise NOT result
            when others  => log_out <= (others => '0'); -- Default case: clear output to all zeros for invalid opcodes
        end case;
    end process;
end Behavioral;