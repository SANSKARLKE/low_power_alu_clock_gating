library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity top_alu is
    Port (
        clk       : in  std_logic;                            -- System clock input
        rst       : in  std_logic;                            -- Synchronous active-high reset
        opcode    : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Primary 4-bit operation select input
        src_A     : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Primary 32-bit input operand A
        src_B     : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Secondary 32-bit input operand B
        alu_out   : out std_logic_vector(DATA_WIDTH-1 downto 0);  -- Final registered 32-bit ALU data output
        alu_flags : out std_logic_vector(7 downto 0)              -- Final registered 8-bit status flags output
    );
end top_alu;

architecture Structural of top_alu is
    -- Input/Output Pipeline Registers
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0);    -- Registered operand inputs
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0);       -- Registered opcode control signal
    signal out_comb     : std_logic_vector(DATA_WIDTH-1 downto 0);     -- Combinational multiplexed output before registration
    signal flags_comb   : std_logic_vector(7 downto 0);                -- Combinational flags before registration

    -- Intermediate Sub-unit Wires
    signal arith_w, log_w, shift_w, set_w : std_logic_vector(DATA_WIDTH-1 downto 0); -- Outputs from individual sub-modules
    signal c_out, o_out                   : std_logic;                             -- Arithmetic carry and overflow wire signals

    -- Enforce architectural separation for proper analysis and synthesis boundaries
    attribute keep_hierarchy : string;
    attribute keep_hierarchy of U_ARITH : label is "true";
    attribute keep_hierarchy of U_LOGIC : label is "true";
    attribute keep_hierarchy of U_SHIFT : label is "true";
    attribute keep_hierarchy of U_SET   : label is "true";
begin

    -- Synchronous Input Stage: Registers inputs on every rising clock edge
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                reg_A  <= (others => '0'); -- Clear register A on reset
                reg_B  <= (others => '0'); -- Clear register B on reset
                reg_op <= (others => '0'); -- Clear opcode register on reset
            else
                reg_A  <= src_A;           -- Latch source operand A
                reg_B  <= src_B;           -- Latch source operand B
                reg_op <= opcode;          -- Latch opcode control signal
            end if;
        end if;
    end process;

    -- Instantiations: Data flows directly into all sub-units concurrently (Standard un-gated architecture)
    U_ARITH: entity work.arith_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, arith_out => arith_w, carry_out => c_out, over_out => o_out);

    U_LOGIC: entity work.logic_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, log_out => log_w);

    U_SHIFT: entity work.shift_unit 
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, shift_out => shift_w);

    U_SET: entity work.set_unit
        port map (op_sel => reg_op, in_A => reg_A, in_B => reg_B, set_out => set_w);

    -- Top-Level Multiplexer Output Selection and Status Flag Generation
    process(reg_op, arith_w, log_w, shift_w, set_w, c_out, o_out)
        variable v_out   : std_logic_vector(DATA_WIDTH-1 downto 0);
        variable v_flags : std_logic_vector(7 downto 0);
    begin
        v_out   := (others => '0');
        v_flags := (others => '0');

        -- Use top 2 bits of opcode to select which functional module output drives the datapath
        case reg_op(3 downto 2) is
            when "00" => 
                v_out := arith_w;          -- Select Arithmetic Unit output
                v_flags(0) := c_out;       -- Assign Carry flag
                v_flags(1) := o_out;       -- Assign Overflow flag
            when "01" => 
                v_out := log_w;            -- Select Logic Unit output
            when "10" => 
                v_out := shift_w;          -- Select Shift Unit output
            when "11" => 
                v_out := set_w;            -- Select Set/Comparison Unit output
            when others => 
                null;
        end case;

        if v_out = x"00000000" then v_flags(2) := '1'; end if; -- Set Zero flag if result is all zeros
        v_flags(3) := v_out(DATA_WIDTH-1);                     -- Set Sign flag to match the most significant bit

        out_comb   <= v_out;
        flags_comb <= v_flags;
    end process;

    -- Synchronous Output Stage: Registers final output data and flags
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                alu_out   <= (others => '0'); -- Clear ALU output on reset
                alu_flags <= (others => '0'); -- Clear ALU flags on reset
            else
                alu_out   <= out_comb;        -- Register final computed datapath result
                alu_flags <= flags_comb;      -- Register final status flags
            end if;
        end if;
    end process;
end Structural;