library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

package alu_pkg is
    constant DATA_WIDTH : integer := 32;
    constant OP_WIDTH   : integer := 4;

    -- Arithmetic Opcodes (00xx)
    constant OP_ADD  : std_logic_vector(3 downto 0) := "0000"; -- Addition (A + B)
    constant OP_SUB  : std_logic_vector(3 downto 0) := "0001"; -- Subtraction (A - B)
    constant OP_MUL  : std_logic_vector(3 downto 0) := "0010"; -- Unsigned Multiplication (A * B)
    constant OP_INC  : std_logic_vector(3 downto 0) := "0011"; -- Increment A by 1 (A + 1)
    
    -- Logic Opcodes (01xx)
    constant OP_AND  : std_logic_vector(3 downto 0) := "0100"; -- Bitwise AND
    constant OP_OR   : std_logic_vector(3 downto 0) := "0101"; -- Bitwise OR
    constant OP_XOR  : std_logic_vector(3 downto 0) := "0110"; -- Bitwise Exclusive-OR
    constant OP_NOT  : std_logic_vector(3 downto 0) := "0111"; -- Bitwise Inversion (NOT A)
    
    -- Shift Opcodes (10xx)
    constant OP_SLL  : std_logic_vector(3 downto 0) := "1000"; -- Shift Left Logical (fills LSB with 0)
    constant OP_SRL  : std_logic_vector(3 downto 0) := "1001"; -- Shift Right Logical (fills MSB with 0)
    constant OP_SRA  : std_logic_vector(3 downto 0) := "1010"; -- Shift Right Arithmetic (preserves sign bit)
    constant OP_ROR  : std_logic_vector(3 downto 0) := "1011"; -- Rotate Right (LSB wraps around to MSB)
    
    -- Set/Compare Opcodes (11xx)
    constant OP_SLT  : std_logic_vector(3 downto 0) := "1100"; -- Set if Less Than (Signed: A < B)
    constant OP_SLTU : std_logic_vector(3 downto 0) := "1101"; -- Set if Less Than Unsigned (Unsigned: A < B)
    constant OP_SEQ  : std_logic_vector(3 downto 0) := "1110"; -- Set if Equal (A == B)
    constant OP_SNE  : std_logic_vector(3 downto 0) := "1111"; -- Set if Not Equal (A != B)
end alu_pkg;

--verified code