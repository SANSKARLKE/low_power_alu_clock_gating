library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity arith_unit is
    Port (
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Operation select control input
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Primary input operand A
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Secondary input operand B
        arith_out : out std_logic_vector(DATA_WIDTH-1 downto 0); -- Computed arithmetic result output
        carry_out : out std_logic;                                -- Arithmetic carry-out flag
        over_out  : out std_logic                                 -- Arithmetic overflow flag
    );
end arith_unit;

architecture Behavioral of arith_unit is
begin
    process(op_sel, in_A, in_B)
        variable sum_ext : unsigned(DATA_WIDTH downto 0);          -- Extended variable for addition (captures carry-out)
        variable sub_ext : unsigned(DATA_WIDTH downto 0);          -- Extended variable for subtraction (captures borrow/carry)
        variable mul_ext : unsigned((DATA_WIDTH*2)-1 downto 0);    -- Double-width variable for multiplication product
        variable inc_ext : unsigned(DATA_WIDTH downto 0);          -- Extended variable for increment operation
    begin
        -- All internal math blocks calculate simultaneously regardless of opcode selection
        sum_ext := unsigned('0' & in_A) + unsigned('0' & in_B);    -- Compute 33-bit addition
        sub_ext := unsigned('0' & in_A) - unsigned('0' & in_B);    -- Compute 33-bit subtraction
        mul_ext := unsigned(in_A) * unsigned(in_B);                -- Compute 64-bit multiplication product
        inc_ext := unsigned('0' & in_A) + 1;                       -- Compute 33-bit increment

        -- Output selection
        case op_sel is
            when OP_ADD =>
                arith_out <= std_logic_vector(sum_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sum_ext(DATA_WIDTH);
                over_out  <= (in_A(31) xor sum_ext(31)) and (in_B(31) xor sum_ext(31)) and (in_A(31) xnor in_B(31));
            when OP_SUB =>
                arith_out <= std_logic_vector(sub_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sub_ext(DATA_WIDTH);
                over_out  <= (in_A(31) xor sub_ext(31)) and (not(in_B(31)) xor sub_ext(31)) and (in_A(31) xor in_B(31));
            when OP_MUL =>
                arith_out <= std_logic_vector(mul_ext(DATA_WIDTH-1 downto 0));
                carry_out <= '0';
                over_out  <= '0';
            when OP_INC =>
                arith_out <= std_logic_vector(inc_ext(DATA_WIDTH-1 downto 0));
                carry_out <= inc_ext(DATA_WIDTH);
                over_out  <= '0';
            when others =>
                arith_out <= (others => '0');
                carry_out <= '0';
                over_out  <= '0';
        end case;
    end process;
end Behavioral;

--verified code