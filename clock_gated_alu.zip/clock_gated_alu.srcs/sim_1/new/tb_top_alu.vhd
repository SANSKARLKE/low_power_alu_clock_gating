library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity tb_top_alu is
    -- Empty testbench wrapper
end tb_top_alu;

architecture Behavioral of tb_top_alu is
    constant CLK_PERIOD : time := 20 ns; -- 50 MHz Clock

    -- Unit Under Test Signals
    signal clk       : std_logic := '0';
    signal rst       : std_logic := '0';
    signal opcode    : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
    signal src_A     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal src_B     : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal alu_out   : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal alu_flags : std_logic_vector(7 downto 0);
begin
    -- Instantiate the Clock Gated Top ALU Wrapper
    UUT: entity work.top_alu
        port map (
            clk       => clk,
            rst       => rst,
            opcode    => opcode,
            src_A     => src_A,
            src_B     => src_B,
            alu_out   => alu_out,
            alu_flags => alu_flags
        );

    -- 50 MHz Continuous Clock Generation
    clk_process: process
    begin
        clk <= '0'; wait for CLK_PERIOD / 2;
        clk <= '1'; wait for CLK_PERIOD / 2;
    end process;

    -- EXACT Standard Workload Replicated: Force max toggling to evaluate power reduction accurately
    stim_proc: process
        variable var_A : std_logic_vector(DATA_WIDTH-1 downto 0) := x"55555555";
        variable var_B : std_logic_vector(DATA_WIDTH-1 downto 0) := x"AAAAAAAA";
    begin		
        -- Initial Synchronous Reset Sequence
        rst <= '1';
        wait for CLK_PERIOD * 2;
        rst <= '0';
        wait for CLK_PERIOD;

        -- 10 Sweeps of the Workload
        for loop_count in 1 to 10 loop
            for op_val in 0 to 15 loop
                
                -- FORCE MAXIMUM TOGGLING: Invert EVERY single bit on every operation
                var_A := not var_A;
                var_B := not var_B;
                
                -- Apply Opcode and Inverted Operands
                opcode <= std_logic_vector(to_unsigned(op_val, OP_WIDTH));
                src_A  <= var_A;
                src_B  <= var_B; -- Every single pin from 0 to 31 will now actively flip!

                -- Wait to complete the 2-cycle pipeline
                wait for CLK_PERIOD * 2; 
            end loop;
        end loop;

        -- Suspend Simulation End Sequence
        rst <= '1';
        wait for CLK_PERIOD * 2;
        wait;
    end process;
end Behavioral;