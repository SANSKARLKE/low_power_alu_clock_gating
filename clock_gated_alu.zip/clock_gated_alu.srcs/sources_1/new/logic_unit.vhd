library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use work.alu_pkg.ALL;

entity logic_unit is
    Port (
        clk     : in  std_logic;                               -- Gated clock input
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);   -- Operation selector
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Primary operand
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Secondary operand
        log_out : out std_logic_vector(DATA_WIDTH-1 downto 0)  -- Logical result output
    );
end logic_unit;

architecture Behavioral of logic_unit is
    -- Internal isolated registers for operand freezing
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
begin
    -- Synchronous isolation: Drops internal toggle rate to zero when block is gated
    process(clk)
    begin
        if rising_edge(clk) then
            reg_A  <= in_A;
            reg_B  <= in_B;
            reg_op <= op_sel;
        end if;
    end process;

    -- Combinational Logic Stage
    process(reg_op, reg_A, reg_B)
        variable v_and, v_or, v_xor, v_not : std_logic_vector(DATA_WIDTH-1 downto 0);
    begin
        -- Compute logic functions concurrently
        v_and := reg_A and reg_B;
        v_or  := reg_A or reg_B;
        v_xor := reg_A xor reg_B;
        v_not := not reg_A;

        -- Multiplex results based on registered opcode
        case reg_op is
            when OP_AND  => log_out <= v_and;
            when OP_OR   => log_out <= v_or;
            when OP_XOR  => log_out <= v_xor;
            when OP_NOT  => log_out <= v_not;
            when others  => log_out <= (others => '0');
        end case;
    end process;
end Behavioral;