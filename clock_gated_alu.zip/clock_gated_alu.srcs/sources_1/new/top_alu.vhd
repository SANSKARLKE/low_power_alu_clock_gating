library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

-- UNISIM required for Xilinx physical primitive instantiation (BUFGCE)
library UNISIM;
use UNISIM.VComponents.all;

entity top_alu is
    Port (
        clk       : in  std_logic;                                -- Global system clock
        rst       : in  std_logic;                                -- Synchronous active-high reset
        opcode    : in  std_logic_vector(OP_WIDTH-1 downto 0);    -- Target operation
        src_A     : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Input A
        src_B     : in  std_logic_vector(DATA_WIDTH-1 downto 0);  -- Input B
        alu_out   : out std_logic_vector(DATA_WIDTH-1 downto 0);  -- Final computed result
        alu_flags : out std_logic_vector(7 downto 0)              -- Status flags
    );
end top_alu;

architecture Structural of top_alu is
    -- Global Register: Holds the opcode to control the Cycle 2 Output Multiplexer
    signal reg_op : std_logic_vector(OP_WIDTH-1 downto 0);

    -- Clock Gating Enables: Driven by combinatorial decode of the incoming opcode
    signal en_arith, en_logic, en_shift, en_set : std_logic;
    
    -- Gated Clock Networks: Outputs from the BUFGCE primitives
    signal clk_arith, clk_logic, clk_shift, clk_set : std_logic;

    -- Sub-module Wires: Routes outputs back to the central multiplexer
    signal arith_w, log_w, shift_w : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal set_w                   : std_logic;
    signal c_out, o_out            : std_logic;

    -- Intermediate combinations before final output registers
    signal out_comb   : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal flags_comb : std_logic_vector(7 downto 0);

    -- Enforce architectural separation for proper synthesis boundary tracking
    attribute keep_hierarchy : string;
    attribute keep_hierarchy of U_ARITH : label is "true";
    attribute keep_hierarchy of U_LOGIC : label is "true";
    attribute keep_hierarchy of U_SHIFT : label is "true";
    attribute keep_hierarchy of U_SET   : label is "true";
begin

    -- Decode Enables Combinationally for Clock Gates (Look-ahead based on top 2 opcode bits)
    en_arith <= '1' when opcode(3 downto 2) = "00" else '0';
    en_logic <= '1' when opcode(3 downto 2) = "01" else '0';
    en_shift <= '1' when opcode(3 downto 2) = "10" else '0';
    en_set   <= '1' when opcode(3 downto 2) = "11" else '0';

    -- Xilinx Clock Gating Buffers (BUFGCE): Physically interrupts clock trees at the routing layer
    U_CG_ARITH: BUFGCE port map (O => clk_arith, CE => en_arith, I => clk);
    U_CG_LOGIC: BUFGCE port map (O => clk_logic, CE => en_logic, I => clk);
    U_CG_SHIFT: BUFGCE port map (O => clk_shift, CE => en_shift, I => clk);
    U_CG_SET  : BUFGCE port map (O => clk_set,   CE => en_set,   I => clk);

    -- Cycle 1 Stage: The global clock latches the opcode for the MUX routing in Cycle 2.
    -- (The data operands bypass this and go straight to the sub-units to be latched by gated clocks).
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                reg_op <= (others => '0');
            else
                reg_op <= opcode;
            end if;
        end if;
    end process;

    -- Sub-module Instantiations: Data routed globally, but latched internally via unique GATED clocks
    U_ARITH: entity work.arith_unit 
        port map (clk => clk_arith, op_sel => opcode, in_A => src_A, in_B => src_B, arith_out => arith_w, carry_out => c_out, over_out => o_out);

    U_LOGIC: entity work.logic_unit 
        port map (clk => clk_logic, op_sel => opcode, in_A => src_A, in_B => src_B, log_out => log_w);

    U_SHIFT: entity work.shift_unit 
        port map (clk => clk_shift, op_sel => opcode, in_A => src_A, in_B => src_B, shift_out => shift_w);

    U_SET: entity work.set_unit
        port map (clk => clk_set, op_sel => opcode, in_A => src_A, in_B => src_B, set_out => set_w);

    -- Cycle 2: Multiplexer Output Selection (Uses the previously registered global opcode)
    process(reg_op, arith_w, log_w, shift_w, set_w, c_out, o_out)
        variable v_out   : std_logic_vector(DATA_WIDTH-1 downto 0);
        variable v_flags : std_logic_vector(7 downto 0);
    begin
        v_out   := (others => '0');
        v_flags := (others => '0');

        -- Select data from the unit that was successfully activated in Cycle 1
        case reg_op(3 downto 2) is
            when "00" => 
                v_out := arith_w;
                v_flags(0) := c_out;
                v_flags(1) := o_out;
            when "01" => 
                v_out := log_w;
            when "10" => 
                v_out := shift_w;
            when "11" => 
                v_out(0) := set_w; -- Pad the single bit output with 31 zeros
            when others => null;
        end case;

        -- Formulate dynamic Zero and Sign flags
        if v_out = x"00000000" then v_flags(2) := '1'; end if;
        v_flags(3) := v_out(DATA_WIDTH-1);

        out_comb   <= v_out;
        flags_comb <= v_flags;
    end process;

    -- Synchronous Output Latch: Finalizes pipeline stability
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                alu_out   <= (others => '0');
                alu_flags <= (others => '0');
            else
                alu_out   <= out_comb;
                alu_flags <= flags_comb;
            end if;
        end if;
    end process;
end Structural;