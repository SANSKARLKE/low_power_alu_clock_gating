library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity set_unit is
    Port (
        clk     : in  std_logic;                               -- Gated clock input
        op_sel  : in  std_logic_vector(OP_WIDTH-1 downto 0);   -- Operation selector
        in_A    : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Primary operand
        in_B    : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Secondary operand
        set_out : out std_logic                                -- Single bit flag output
    );
end set_unit;

architecture Behavioral of set_unit is
    -- Internal isolated registers for operand freezing
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
begin
    -- Synchronous isolation stage
    process(clk)
    begin
        if rising_edge(clk) then
            reg_A  <= in_A;
            reg_B  <= in_B;
            reg_op <= op_sel;
        end if;
    end process;

    -- Combinational Set/Comparison Stage
    process(reg_op, reg_A, reg_B)
        variable v_bit : std_logic;
    begin
        v_bit := '0'; -- Default to false (0)
        
        -- Evaluate condition based on registered opcode
        case reg_op is
            when OP_SLT  => 
                if signed(reg_A) < signed(reg_B) then v_bit := '1'; end if;
            when OP_SLTU => 
                if unsigned(reg_A) < unsigned(reg_B) then v_bit := '1'; end if;
            when OP_SEQ  => 
                if reg_A = reg_B then v_bit := '1'; end if;
            when OP_SNE  => 
                if reg_A /= reg_B then v_bit := '1'; end if;
            when others  => 
                null;
        end case;
        
        -- Assign the evaluated boolean bit to the output port
        set_out <= v_bit;
    end process;
end Behavioral;