library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity shift_unit is
    Port (
        clk       : in  std_logic;                               -- Gated clock input
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);   -- Operation selector
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Data to shift
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Contains shift amount
        shift_out : out std_logic_vector(DATA_WIDTH-1 downto 0)  -- Shift result output
    );
end shift_unit;

architecture Behavioral of shift_unit is
    -- Internal isolated registers for operand freezing
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
begin
    -- Synchronous isolation stage
    process(clk)
    begin
        if rising_edge(clk) then
            reg_A  <= in_A;
            reg_B  <= in_B;
            reg_op <= op_sel;
        end if;
    end process;

    -- Combinational Shift Stage
    process(reg_op, reg_A, reg_B)
        variable shamt : integer range 0 to 31; -- Integer cast of shift amount
        variable v_sll, v_srl, v_sra, v_ror : std_logic_vector(DATA_WIDTH-1 downto 0);
    begin
        -- Extract lower 5 bits of B to determine shift magnitude
        shamt := to_integer(unsigned(reg_B(4 downto 0)));
        
        -- Compute shift variants concurrently
        v_sll := std_logic_vector(shift_left(unsigned(reg_A), shamt));
        v_srl := std_logic_vector(shift_right(unsigned(reg_A), shamt));
        v_sra := std_logic_vector(shift_right(signed(reg_A), shamt));
        v_ror := std_logic_vector(rotate_right(unsigned(reg_A), shamt));

        -- Multiplex results based on registered opcode
        case reg_op is
            when OP_SLL  => shift_out <= v_sll;
            when OP_SRL  => shift_out <= v_srl;
            when OP_SRA  => shift_out <= v_sra;
            when OP_ROR  => shift_out <= v_ror;
            when others  => shift_out <= (others => '0');
        end case;
    end process;
end Behavioral;