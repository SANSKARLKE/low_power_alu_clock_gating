library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

package alu_pkg is
    -- System Constants: Defines the bus widths used across all ALU modules
    constant DATA_WIDTH : integer := 32; -- 32-bit datapath
    constant OP_WIDTH   : integer := 4;  -- 4-bit instruction opcode

    -- Arithmetic Opcodes (00xx): Route to arith_unit
    constant OP_ADD : std_logic_vector(3 downto 0) := "0000"; -- Addition
    constant OP_SUB : std_logic_vector(3 downto 0) := "0001"; -- Subtraction
    constant OP_MUL : std_logic_vector(3 downto 0) := "0010"; -- Multiplication
    constant OP_INC : std_logic_vector(3 downto 0) := "0011"; -- Increment A by 1

    -- Logic Opcodes (01xx): Route to logic_unit
    constant OP_AND : std_logic_vector(3 downto 0) := "0100"; -- Bitwise AND
    constant OP_OR  : std_logic_vector(3 downto 0) := "0101"; -- Bitwise OR
    constant OP_XOR : std_logic_vector(3 downto 0) := "0110"; -- Bitwise XOR
    constant OP_NOT : std_logic_vector(3 downto 0) := "0111"; -- Bitwise NOT (Invert A)

    -- Shift Opcodes (10xx): Route to shift_unit
    constant OP_SLL : std_logic_vector(3 downto 0) := "1000"; -- Shift Left Logical
    constant OP_SRL : std_logic_vector(3 downto 0) := "1001"; -- Shift Right Logical
    constant OP_SRA : std_logic_vector(3 downto 0) := "1010"; -- Shift Right Arithmetic
    constant OP_ROR : std_logic_vector(3 downto 0) := "1011"; -- Rotate Right

    -- Set/Compare Opcodes (11xx): Route to set_unit
    constant OP_SLT  : std_logic_vector(3 downto 0) := "1100"; -- Set if Less Than (Signed)
    constant OP_SLTU : std_logic_vector(3 downto 0) := "1101"; -- Set if Less Than (Unsigned)
    constant OP_SEQ  : std_logic_vector(3 downto 0) := "1110"; -- Set if Equal
    constant OP_SNE  : std_logic_vector(3 downto 0) := "1111"; -- Set if Not Equal
end alu_pkg;