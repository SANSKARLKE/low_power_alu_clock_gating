library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
use work.alu_pkg.ALL;

entity arith_unit is
    Port (
        clk       : in  std_logic;                               -- Gated clock input (only active when enabled)
        op_sel    : in  std_logic_vector(OP_WIDTH-1 downto 0);   -- Operation selector
        in_A      : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Primary operand
        in_B      : in  std_logic_vector(DATA_WIDTH-1 downto 0); -- Secondary operand
        arith_out : out std_logic_vector(DATA_WIDTH-1 downto 0); -- Math result output
        carry_out : out std_logic;                               -- Carry status flag
        over_out  : out std_logic                                -- Overflow status flag
    );
end arith_unit;

architecture Behavioral of arith_unit is
    -- Internal isolated registers: Hold previous values when clock is gated off
    signal reg_A, reg_B : std_logic_vector(DATA_WIDTH-1 downto 0) := (others => '0');
    signal reg_op       : std_logic_vector(OP_WIDTH-1 downto 0)   := (others => '0');
begin
    -- Input Isolation Stage: Registers only update when this unit receives clock pulses.
    -- If clock is gated, registers hold state, meaning downstream logic sees ZERO switching activity.
    process(clk)
    begin
        if rising_edge(clk) then
            reg_A  <= in_A;
            reg_B  <= in_B;
            reg_op <= op_sel;
        end if;
    end process;

    -- Combinational Math Stage: Operates purely on the isolated internal registers
    process(reg_op, reg_A, reg_B)
        variable sum_ext, sub_ext, inc_ext : unsigned(DATA_WIDTH downto 0);       -- 33-bit variables for tracking carry
        variable mul_ext : unsigned((DATA_WIDTH*2)-1 downto 0);                   -- 64-bit variable for multiplication
    begin
        -- Compute all arithmetic operations concurrently
        sum_ext := unsigned('0' & reg_A) + unsigned('0' & reg_B);
        sub_ext := unsigned('0' & reg_A) - unsigned('0' & reg_B);
        mul_ext := unsigned(reg_A) * unsigned(reg_B);
        inc_ext := unsigned('0' & reg_A) + 1;

        -- Select output and calculate flags based on registered opcode
        case reg_op is
            when OP_ADD =>
                arith_out <= std_logic_vector(sum_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sum_ext(DATA_WIDTH);
                over_out  <= (reg_A(31) xnor reg_B(31)) and (reg_A(31) xor sum_ext(31)); -- Same sign inputs, different sign output
            when OP_SUB =>
                arith_out <= std_logic_vector(sub_ext(DATA_WIDTH-1 downto 0));
                carry_out <= sub_ext(DATA_WIDTH);
                over_out  <= (reg_A(31) xor reg_B(31)) and (reg_A(31) xor sub_ext(31));  -- Different sign inputs, wrong sign output
            when OP_MUL =>
                arith_out <= std_logic_vector(mul_ext(DATA_WIDTH-1 downto 0));
                carry_out <= '0'; -- Carry/Overflow unused for baseline 32-bit mult
                over_out  <= '0';
            when OP_INC =>
                arith_out <= std_logic_vector(inc_ext(DATA_WIDTH-1 downto 0));
                carry_out <= inc_ext(DATA_WIDTH);
                over_out  <= (reg_A(31) xnor '0') and (reg_A(31) xor inc_ext(31));
            when others =>
                arith_out <= (others => '0'); -- Default safe state
                carry_out <= '0';
                over_out  <= '0';
        end case;
    end process;
end Behavioral;